/*
   THE FOLLOWING CODE IS PROVIDED AS IS. THE AUTHOR  MAKES NO REPRESENTATIONS 
   OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, INCLUDING BUT NOT LIMITED 
   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR  SHALL NOT BE 
   LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
   OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

*/

/**
CustomClassLoader.java
This is a CustomClassLoader implemented according to the Java 1.2 parent delegation
model. It extends java.lang.Classloader & implements the findClass method. The class
loader searches in the searchPath specified in the constructor, to load classes. This
implementation doesnot look for classes in jar/zip files, the searchPath is a list of
directories.

*/

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;

public class CustomClassLoader extends ClassLoader {

    private List classRepository;//class repository where findClass performs its search

    public CustomClassLoader(ClassLoader parent,String searchPath) {
	super(parent);
	initLoader(searchPath);	
    }

    public CustomClassLoader(String searchPath) {
	super(CustomClassLoader.class.getClassLoader());
	initLoader(searchPath);
    }

    /**
    This method overrides the findClass method in the java.lang.ClassLoader
    Class. The method will be called from the loadClass method of the parent
    class loader when it is unable to find a class to load. 
    This implementation will look for the class in the class repository.

    @param className A String specifying the class to be loaded
    @return  A Class object which is loaded into the JVM by the CustomClassLoader
    @throws ClassNotFoundException if the method is unable to load the class
    */
    protected Class findClass(String className)
	throws ClassNotFoundException
    {	
	byte[] classBytes = loadFromCustomRepository(className);
	if(classBytes != null) {
		return defineClass(className,classBytes,0,classBytes.length);
	    }
	//else
	throw new ClassNotFoundException(className);
    }

    /* 
       A private method that loads binary class file data from the classRepository.        
    */
    private byte[] loadFromCustomRepository(String classFileName) 
	throws ClassNotFoundException {
	Iterator dirs = classRepository.iterator();
	byte[] classBytes = null;
	while (dirs.hasNext()) {
	    String dir = (String) dirs.next();
	    //replace '.' in the class name with File.separatorChar & append .class to the name
	    //String classFileName = className;
	    classFileName.replace('.',File.separatorChar);
	    classFileName += ".class";
	    try {
		File file = new File(dir,classFileName);
		if(file.exists () ) {
		    //read file
		    InputStream is = new FileInputStream(file);
		    classBytes = new byte[is.available()];
		    is.read(classBytes);		    
		    break;
		}
	    }
	    catch(IOException ex) {
		//return null
		System.out.println("IOException raised while reading class file data");
		ex.printStackTrace();
		return null;
	    }
	}
	return classBytes;
    }

    private void initLoader(String searchPath) {	
	//userClassPath is passed in as a string of directories/jar files separated
        //by the File.pathSeparator
	classRepository = new ArrayList();
	if( (searchPath != null) && !(searchPath.equals("")) ) {
	    StringTokenizer tokenizer = new StringTokenizer(searchPath,File.pathSeparator);
	    while(tokenizer.hasMoreTokens()) {
		classRepository.add(tokenizer.nextToken());
	    }
	}
	
    }
}
