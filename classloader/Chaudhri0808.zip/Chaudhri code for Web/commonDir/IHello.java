
public interface IHello {
    public void sayHello();
}
