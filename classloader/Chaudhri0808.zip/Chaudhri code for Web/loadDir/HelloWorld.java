public class HelloWorld implements IHello {
    public void sayHello() {
	System.out.println("Hello World");
	//System.out.println("I got loaded again!!");
    }
    
}
