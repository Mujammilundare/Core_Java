/*
   THE FOLLOWING CODE IS PROVIDED AS IS. THE AUTHOR  MAKES NO REPRESENTATIONS 
   OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, INCLUDING BUT NOT LIMITED 
   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR  SHALL NOT BE 
   LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
   OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.

*/
public class TestCustomLoader
{
    public static void main(String [] args) {
	if(args.length < 2) {
	    System.out.println("Usage Java CustomClassLoader [code repository] [class to load]");
	    System.exit(1);
	}
	String repository = args[0];
	String classToLoad = args[1];
	try {
	    ClassLoader customLoader = new CustomClassLoader(repository);
	    loadAndInvoke(customLoader,classToLoad);
	    System.out.println("waiting.Hit Enter to continue");

	    System.in.read();
	    
	    System.out.println("Reinstantiating the loader.");	
	    customLoader = new CustomClassLoader(repository);              
	    loadAndInvoke(customLoader,classToLoad);           
	    
	}
	catch(Exception ex) {
	    System.out.println("Exception raised : " + ex.getMessage());
	    ex.printStackTrace();
	}	
    }

    static void loadAndInvoke(ClassLoader customLoader,String helloClass)
	throws Exception
    {
	Class aClass = customLoader.loadClass(helloClass);
	System.out.println("class loaded");
	IHello helloObj = (IHello) aClass.newInstance();
	helloObj.sayHello();
    }
}
