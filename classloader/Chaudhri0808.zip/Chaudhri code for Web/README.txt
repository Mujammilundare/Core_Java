contents of the directory:

classloader.doc: The classloader article
CustomClassLoader.java : Implementation of a custom classloader.
TestCustomLoader.java: A test program that uses CustomClasLoader to demonstrate hot deployment.

commonDir : A directory containing an interface IHello.java
loadDir : A directory containing a class HelloWorld.java which implements IHello.java
AuthorInfo.txt: miscellaneous info needed by JDJ (author bio, contact info etc)


The following command compiles CustomClassLoader & TestCustomClassLoader
javac -classpath ".;./commonDir" CustomClassLoader.java TestCustomLoader.java

The following command compiles HelloWorld.java in the directory 'loadDir'
javac -classpath ".;../commonDir" HelloWorld.java

The following command executes TestCustomLoader : 
java -classpath ".;./commonDir" TestCustomLoader loadDir HelloWorld

commandline arguments :
classpath: The classpath for the JVM
loadDir: name of the directory where CustomClassLoader searches for a class to be loaded
HelloWorld: name of the class to be loaded by CustomClassLoader.